
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddContactComponent } from './PhoneBook-App/add-contact/add-contact.component';
import { ContactComponent } from './PhoneBook-App/contact/contact.component';


//import { EditUserComponent} from './components/edit-user/edit-user.component';

const routes: Routes = [
  { path: "contact", component:ContactComponent},
  { path: "", component:ContactComponent},
  { path: "add-contact", component:AddContactComponent},
  //{ path: "edit-user", component:EditUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
