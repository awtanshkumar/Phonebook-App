import { TestBed } from '@angular/core/testing';
import { ContactsService } from './contact.service';



describe('ContactService', () => {
  let service: ContactsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContactsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
