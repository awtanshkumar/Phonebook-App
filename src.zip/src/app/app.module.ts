import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactComponent } from './PhoneBook-App/contact/contact.component';
import { AddContactComponent } from './PhoneBook-App/add-contact/add-contact.component';
import { SearchPipe } from './PhoneBook-App/search.pipe';
import { ContactsService } from './PhoneBook-App/contact.service';


@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    AddContactComponent,
    SearchPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [ContactsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
